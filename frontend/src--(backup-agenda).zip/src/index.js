// React Library
import React from 'react';

// Reacty Library para manipular o DOM - (Árvore de Elementos)
import ReactDOM from 'react-dom';

import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));